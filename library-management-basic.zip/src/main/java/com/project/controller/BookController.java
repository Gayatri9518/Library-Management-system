package com.project.controller;

import com.project.model.Book;
import com.project.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {
    @Autowired
    private BookRepository bookRepo;

    @PostMapping
    public Book addBook(@RequestBody Book book) {
        book.setAvailableCopies(book.getTotalCopies());
        return bookRepo.save(book);
    }

    @GetMapping
    public List<Book> getAllBooks() {
        return bookRepo.findAll();
    }
}
